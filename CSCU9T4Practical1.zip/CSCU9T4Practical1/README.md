# CSCU9T4Practical1
The starter code for Java Practical exercise number 1 in CSCU9T4  
This is a Netbeans project but you can import it to an IDE of your choice.  
Instructions on doing so can be found by simply searching for:
```
[insert IDE name here] import Netbeans project
```
I have successfully imported to:
- Eclipse
- IntelliJ

Alternatively you can just checkout with Git and use any plain text editor.  
I recommend:
- Notepad++
- Emacs (if you've used it before)
- Vim (again, if you've used it before)

Fork the repository to your own one before checking it out to your laptop/pc to work on.  
That way you can use your own repository to keep control of versioning of your own code.
